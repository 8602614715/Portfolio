export type ApiHealth = {
  status: 'ok' | 'degraded' | 'offline'
  service: string
  version?: string
  timestamp?: string
}

export type ContactMessageInput = {
  name: string
  email: string
  message: string
}

export type ContactMessageResponse = {
  id: string
  status: 'queued' | 'sent'
  message: string
}

export type ApiError = {
  detail: string
  code?: string
}

export type ApiRequestOptions = Omit<RequestInit, 'body'> & {
  body?: unknown
}
