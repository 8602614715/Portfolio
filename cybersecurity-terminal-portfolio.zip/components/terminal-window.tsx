'use client'

import { useRef, useState } from 'react'

type TerminalLine = { prompt?: string; text: string; tone?: 'accent' | 'muted' | 'info' }

const commandOutput: Record<string, string[]> = {
  help: ['Available commands:', '  about      operator profile', '  skills     technical capabilities', '  projects   selected work', '  contact    secure channels', '  ls / dir   list workspace files', '  cat file   read a workspace file', '  cd <dir>   change directory', '  pwd        print working directory', '  whoami     show current user', '  date       show system date', '  clear/cls  clear session', '  history    command history', '  ver        Windows version alias', '  uname -a   system information'],
  about: ['SATYAM PRAJAPATI', 'Cybersecurity Engineer / Backend Developer', 'Building secure systems, APIs and resilient infrastructure.'],
  skills: ['CORE CAPABILITIES', 'Python · FastAPI · React · TypeScript', 'PostgreSQL · Linux · Nmap · Burp Suite', 'OWASP · API Security · Networking'],
  projects: ['SELECTED WORK', 'cyber fraud detection system', 'healthcare automation system', 'network security lab'],
  contact: ['SECURE CHANNELS', 'email    your.email@example.com', 'github   github.com/yourusername', 'linkedin linkedin.com/in/yourusername'],
  pwd: ['/home/satyam/portfolio'],
  whoami: ['satyam'],
  hostname: ['satyam-portfolio'],
  date: [new Date().toString()],
  ver: ['Microsoft Windows [Version 11.0.26100.1]', 'Portfolio Terminal Compatibility Layer'],
  'uname -a': ['Linux satyam-portfolio 6.8.0-portfolio x86_64 GNU/Linux'],
  ipconfig: ['Windows IP Configuration', '', 'Ethernet adapter SecureLink:', '   IPv4 Address . . . . . . . . . : 192.168.1.42', '   Default Gateway . . . . . . . : 192.168.1.1'],
  ifconfig: ['eth0: flags=4163<UP,BROADCAST,RUNNING>  mtu 1500', '    inet 192.168.1.42  netmask 255.255.255.0', '    status: secure / monitored'],
  'cat readme.md': ['# SATYAM PRAJAPATI', '', 'Security-minded engineer building reliable backend systems.', 'Use `help` to explore this portfolio.'],
  'cat about.txt': ['Operator profile: cybersecurity engineer and backend developer.', 'Mission: build secure, useful, resilient software.'],
  neofetch: ['       .--.       satyam@portfolio', '      |o_o |      ----------------', '      |:_/ |      OS: SATYAM OS', '     //   \\      Shell: portfolio-sh', '    (|     |)     Uptime: always learning', '   /\\_   _/\\     Security: enabled'],
}

const files = ['about.txt', 'contact.txt', 'projects/', 'skills/', 'README.md']

export function TerminalWindow() {
  const [history, setHistory] = useState<TerminalLine[]>([])
  const [input, setInput] = useState('')
  const [cwd, setCwd] = useState('~')
  const [commandHistory, setCommandHistory] = useState<string[]>([])
  const [historyIndex, setHistoryIndex] = useState(-1)
  const inputRef = useRef<HTMLInputElement>(null)

  function runCommand(value: string) {
    const raw = value.trim()
    const command = raw.toLowerCase()
    if (!raw) return
    setCommandHistory((current) => [...current, raw])
    setHistoryIndex(-1)
    if (command === 'clear' || command === 'cls') {
      setHistory([])
      setInput('')
      return
    }
    if (command === 'ls' || command === 'ls -la' || command === 'dir') {
      setHistory((current) => [...current, { prompt: raw, text: '' }, ...files.map((text) => ({ text, tone: 'info' as const }))])
      setInput('')
      return
    }
    if (command === 'cd' || command === 'cd ~' || command === 'cd /home/satyam/portfolio') {
      setCwd('~')
      setHistory((current) => [...current, { prompt: raw, text: '' }])
      setInput('')
      return
    }
    if (command.startsWith('cd ')) {
      const target = raw.slice(3).trim()
      if (['projects', 'skills', 'about.txt'].includes(target)) setCwd(`~/${target.replace('.txt', '')}`)
      else setHistory((current) => [...current, { prompt: raw, text: `bash: cd: ${target}: No such file or directory`, tone: 'muted' }])
      setInput('')
      return
    }
    if (command.startsWith('echo ')) {
      setHistory((current) => [...current, { prompt: raw, text: raw.slice(5) }])
      setInput('')
      return
    }
    const output = commandOutput[command] ?? (command.startsWith('cat ') ? [`cat: ${raw.slice(4)}: No such file or directory`] : [`${command}: command not found`, 'Type "help" for available commands.'])
    setHistory((current) => [...current, { prompt: raw, text: '' }, ...output.map((text) => ({ text, tone: text.includes('not found') || text.includes('No such') ? 'muted' as const : undefined }))])
    setInput('')
  }

  function handleKeyDown(event: React.KeyboardEvent<HTMLInputElement>) {
    if (event.key === 'ArrowUp') {
      event.preventDefault()
      const next = Math.max(0, commandHistory.length - 1 - Math.max(historyIndex, 0))
      setHistoryIndex(commandHistory.length - 1 - next)
      setInput(commandHistory[next] ?? '')
    }
    if (event.key === 'ArrowDown') {
      event.preventDefault()
      const next = historyIndex + 1
      if (next >= commandHistory.length) { setHistoryIndex(-1); setInput('') } else setInput(commandHistory[next])
    }
  }

  const prompt = `satyam@portfolio:${cwd}$`
    const lines = history


  return (
    <div className="terminal-window" id="terminal" aria-label="Interactive portfolio terminal" onClick={() => inputRef.current?.focus()}>
      <div className="terminal-header">
        <div className="terminal-controls" aria-hidden="true"><i /><i /><i /></div>
        <span>satyam@portfolio:{cwd}</span>
        <span className="terminal-header-status">LIVE SESSION · UTF-8</span>
      </div>
      <div className="terminal-body" aria-live="polite">
        <div className="terminal-output">
          {lines.map((line, index) => (
            <div className={`terminal-line ${line.prompt ? 'terminal-prompt' : ''} ${line.tone === 'accent' ? 'terminal-accent' : ''} ${line.tone === 'muted' ? 'terminal-muted' : ''}`} key={`${line.prompt ?? line.text}-${index}`}>
              {line.prompt && <><span className="terminal-user">{prompt}</span><span>{line.prompt}</span></>}
              {!line.prompt && <span>{line.text}</span>}
            </div>
          ))}
        </div>
        <form className="terminal-input-row" onSubmit={(event) => { event.preventDefault(); runCommand(input) }}>
          <span className="terminal-user" aria-hidden="true">{prompt}</span>
          <label className="sr-only" htmlFor="terminal-command">Terminal command</label>
          <input ref={inputRef} id="terminal-command" value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={handleKeyDown} autoComplete="off" spellCheck={false} placeholder="type a command..." autoFocus />
          <span className="terminal-cursor" aria-hidden="true">_</span>
        </form>
      </div>
      <div className="terminal-scanlines" aria-hidden="true" />
    </div>
  )
}

export default TerminalWindow
